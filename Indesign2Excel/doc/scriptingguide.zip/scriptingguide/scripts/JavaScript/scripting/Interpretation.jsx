//Interpretation.jsx
//An InDesign CS6 JavaScript
//
//Set the preferred scripting object model used for the interpretation of results.

//<fragment>
//Set to the 4.0 scripting object model
app.scriptPreferences.version = 4.0;
//</fragment>

dummy();

function dummy(){
    alert("Not a stand-alone script. Exists to provide sample code for documentation.");
}

